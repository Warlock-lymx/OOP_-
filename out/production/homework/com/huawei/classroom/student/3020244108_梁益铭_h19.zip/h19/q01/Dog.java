package com.huawei.classroom.student.h19.q01;

public class Dog {
    public String speak() {
        String res = "wangwang";
        return res;
    }
}
