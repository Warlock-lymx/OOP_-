package com.huawei.classroom.student.h07;

public enum EnumObjectType {
	heavyTank,mediumTank,rifleSoldier,RPGSoldier,dog,barrack,warFactory
}
