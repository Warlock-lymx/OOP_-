package com.huawei.classroom.student.h59;

import java.util.HashSet;
import java.util.Set;

public class Reaction {
    public Set<String> reactant = new HashSet<>();
    public Set<String> resultant = new HashSet<>();

    public Reaction(Set<String> reactant, Set<String> resultant) {
        this.reactant = reactant;
        this.resultant = resultant;
    }


}
