package com.huawei.classroom.student.h83.q04;

import java.util.List;
//TODO Auto-generated constructor stub //{8b3f78379bd4ce609ea88955223a3d95}
public class ListUtil {
	// TODO Auto-generated constructor stub //{8d53e2c7fa024017c48c9d59726cac86}
	/**
	 * 计算一个list里面所有整数的加和，并将结果返回
	 * @param list
	 * @return
	 */
	public double getSum(List<Integer> list) {
		//
		// TODO Auto-generated constructor stub //{8ee5ba84a1dede02cd229d4f28548697}
        int sum = 0;
        for(int i:list) {
            sum+=i;
        }
        return sum;
	}
}
//TODO Auto-generated constructor stub //{8f258801244da590cdf1ca7925035738}