//package com.huawei.classroom.student.h83.q06;
//
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.LineNumberReader;
//import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.List;
//
//public class MyQueueUtil {
//	// TODO Auto-generated constructor stub //{a422d3f6f442077a719e0bbc2c0c4b26}
//	/**
//	 * 统计一次核酸检测中所有市民的平均等待时间（以秒为单位）
//	 * 每个医生检测一个核酸检测需要50秒
//	 * 某医生如果在第1秒给第1个市民做核酸，则这个医生在第51秒可以给第2个市民做核酸，第101秒给第3个市民做核酸...
//	 * 一个市民如果第1秒到达并且立刻做核酸，则其等待时间为0,如果第51秒做核酸则其等待时间为50
//	 * @param dataFile 存放了核酸检测场所市民到达情况的文件
//	 * @param doctorCount 共计核酸检测医生的数量
//	 *
//	 * @return
//	 */
//	public double getAvgWait(String dataFile, int doctorCount) {
//		// TODO Auto-generated constructor stub //{a4402254b973b6f8e92e630db3dfa71c}
//		//
//	}
//	//
//	//
//}
////TODO Auto-generated constructor stub //{a4b4a63710eba3797ce75ed82701ea5b}