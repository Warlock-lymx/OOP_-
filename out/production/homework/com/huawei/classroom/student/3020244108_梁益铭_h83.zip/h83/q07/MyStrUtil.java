package com.huawei.classroom.student.h83.q07;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//TODO Auto-generated constructor stub //{baf7818a1d47b2c98098f21904f247b9}
public class MyStrUtil {

    /**
     * 判断str中是否包含了所有的英文字母（不区分小写)
     *
     * @param str
     * @return 如果包含了全部的英文字母则返回true，否则 false
     */
    public boolean containsAllLetters(String str) {
        //
        // TODO Auto-generated constructor stub //{bd1caca35e9baf07da31fe3e75944461}
        Set<Character> set = new HashSet<>();
        List<Character> target = new ArrayList<>();
        List<Character> upTarget = new ArrayList<>();
        for (int i = 0; i < 26; i++) {
            target.add((char) ('a' + i));
        }
        for (int i = 0; i < 26; i++) {
            upTarget.add((char) ('A' + i));
        }
        int flag = 0;
        int[] s = new int[26];
        for (int i = 0; i < s.length; i++) {
            s[i]=0;
        }
        for (int i = 0; i < str.length(); i++) {
            for (int j = 0; j < 26; j++) {
                if ((str.charAt(i) == target.get(j)&&s[j]==0) || (str.charAt(i) == upTarget.get(j)&&s[j]==0)){
                    flag++;
                    s[j]=1;
                }


            }
        }
        if (flag == 26) return true;
        else return false;
    }
}
//TODO Auto-generated constructor stub //{bee6c2c71c225e12e2f4440df5fccf17}