//package com.huawei.classroom.student.h83.q08;
//
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.Set;
////TODO Auto-generated constructor stub //{c9bb6705a370798a75f6488b9be0efab}
//public class MyPointUtil {
//
//	/**
//	 * 湖里有很多小岛 allPoints，每个岛坐标用 整数X，Y表示。 一只猫现在站在小岛src上，这个猫每次最远跳跃距离是jumpLen
//	 *
//	 * @param src
//	 *            猫目前所在的小岛
//	 * @param allPoints
//	 *            湖里面所有的岛
//	 * @param jumpLen
//	 *            猫单次跳跃最大距离
//	 * @return 返回这个猫所有可达的岛屿(包括起点岛屿)
//	 */
//	public Set<Point> getAllReachablePoints(Point src, Set<Point> allPoints, double jumpLen) {
//		//
//		// TODO Auto-generated constructor stub //{cafe269bd81f8907de2d04c33008292e}
//	}
//
//	//
//}
////TODO Auto-generated constructor stub //{d1116cecc6ae582f31db3cc57914395c}