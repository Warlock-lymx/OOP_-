//package com.huawei.classroom.student.h83.q09;
///**
// * @author  //{e3b9034a5099bda27d62e05a64951e55}
// */
////TODO Auto-generated constructor stub //{e4bbf0935d2cec5eab9bd75a5b61c686}
//public class Classq09 {
//
//	/**
//	 * line是一行java代码程序,其中可能包含一段注释，请用程序把这段注释抽取出来，如果不包含注释则返回""
//	 * @param line
//	 * @return
//	 */
//	public String extractComment(String line) {
//		// TODO Auto-generated constructor stub //{e5ac914e6484c57f07b75d4cb5b70169}
//		//
//	}
//	/**
//	 * 计算函数fx在x 点的导数值
//	 * // TODO Auto-generated constructor stub //{e745883e18539aa9a7805257b2267172}
//	 * @param fx
//	 * @param x
//	 * @return
//	 */
//	public double getDxValue(String fx,double x) {
//		// TODO Auto-generated constructor stub //{e74cebf3c9a4d854fb05b9843697ba42}
//		//
//	}
//
//	/**
//	 * // TODO Auto-generated constructor stub //{edd88995f1e2c85345fd96f6152e3c81}
//	 * 计算fx的导数表达式
//	 * @param fx
//	 * @return
//	 */
//	public String getDxExp(String fx) {
//
//		// TODO Auto-generated constructor stub //{efc83690e2ee72f4399df7b58a4faaa1}
//		//
//	}
//}
////TODO Auto-generated constructor stub //{efe85345c401ef51f8648ab701551aaf}