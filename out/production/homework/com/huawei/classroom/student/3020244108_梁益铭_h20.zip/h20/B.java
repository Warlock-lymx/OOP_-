package com.huawei.classroom.student.h20;

public interface B {
}
