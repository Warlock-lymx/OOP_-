package com.huawei.classroom.student.h20;

public class D extends A implements C {
}
