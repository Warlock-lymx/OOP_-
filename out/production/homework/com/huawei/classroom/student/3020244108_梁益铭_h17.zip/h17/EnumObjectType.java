package com.huawei.classroom.student.h17;

public enum EnumObjectType {
    barrack, warFactory, rifleSoldier, RPGSoldier, dog, heavyTank, mediumTank
}
