package com.huawei.classroom.student.h14;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 在本包下增加合适的类和方法， 本程序不但要测试通过，还需要写适当的注释
 * <p>
 * 不要引用jdk1.8以外第三方的包
 *
 * @author cjy
 */
public class MyTools {

    /**
     * @param studentListFile 存放学生名单的文件名
     * @param picDir          图片存放的目录（不会包含子目录）
     */
    public MyTools() {
        // TODO Auto-generated constructor stub
    }

    public String readFromText(String filename) {
        Reader reader = null;
        StringBuffer buf = new StringBuffer();
        char[] content = new char[1000];
        try {
            FileInputStream fileInputStream = new FileInputStream(filename);
            reader = new InputStreamReader(fileInputStream, "UTF-8");
            int readed = 0;
            while ((readed = reader.read(content)) != -1) {
                buf.append(content, 0, readed);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return buf.toString();
    }

    public Set<String> copyToTargetDirAndReturnNoExist(String studentListFile, String srcDir, String target) throws Exception {
        String[] stuInfo = readFromText(studentListFile).split("[\n\t]");
        Map<String, String> stuName = new HashMap<String,String>();
        Map<String, String> stuClass = new HashMap<String, String>();
        Set<String> handedNum = new HashSet<>();

        for (int i = 0; i < stuInfo.length; i += 3) {
            stuName.put(stuInfo[i], stuInfo[i + 1]);
            stuClass.put(stuInfo[i], stuInfo[i + 2].replace("\r", ""));
        }
        File dir = new File(srcDir);
        String[] filename = dir.list();
        for (int i = 0; i < filename.length; i++) {
            if (!(filename[i].substring(filename[i].length() - 4, filename[i].length()).equals(".jpg")))
                continue;

            else {
                String stuNum = filename[i].replace(".jpg", "");
                if (stuName.containsKey(stuNum)) {
                    handedNum.add(stuNum);
                    File classFile = new File(target,stuClass.get(stuNum));
                    if(!classFile.exists()) {
                        classFile.mkdirs();
                    }
                    File destFile = new File(classFile,stuNum+"_"+stuName.get(stuNum)+".jpg");
                    if(!destFile.exists()) {
                        destFile.createNewFile();
                    }
                    try{
                        FileInputStream fileInputStream = new FileInputStream(srcDir+"\\"+stuNum+".jpg");
                        FileOutputStream fileOutputStream = new FileOutputStream(destFile);
                        byte[] content = new byte[1000];
                        int readed = 0;
                        while((readed=fileInputStream.read(content))!=-1) {
                            fileOutputStream.write(content,0,readed);
                        }
                        fileInputStream.close();
                        fileOutputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                } else continue;
            }
        }

        Set<String> allNum = stuName.keySet();
        Set<String> unhandedNum = new HashSet<>();
        for(String num : allNum) {
            if(handedNum.contains(num)) {
                continue;
            }
            else {
                unhandedNum.add(num);
            }
        }
        return unhandedNum;
    }


}
