package com.huawei.classroom.student.h05;

public class Building extends Base{
    public Building(int hp, int atk) {
        super(hp, atk);
    }
}
