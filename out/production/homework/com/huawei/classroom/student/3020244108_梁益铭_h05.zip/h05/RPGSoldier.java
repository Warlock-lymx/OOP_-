package com.huawei.classroom.student.h05;

public class RPGSoldier extends Soldier {
    public RPGSoldier() {
        super(50, 10);
    }
}
