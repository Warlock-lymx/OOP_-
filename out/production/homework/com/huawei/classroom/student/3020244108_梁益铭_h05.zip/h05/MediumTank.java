package com.huawei.classroom.student.h05;

public class MediumTank extends Tank {
    public MediumTank() {
        super(100, 10);
    }
}
