package com.huawei.classroom.student.h05;

public enum EnumObjectType {
    rifleSoldier, RPGSoldier, dog, mediumTank, heavyTank;
}
