package com.huawei.classroom.student.h05;

public class Tank extends Base {
    public Tank(int hp, int atk) {
        super(hp, atk);
    }
}
