package com.huawei.classroom.student.h99.q02;

public class MyT2 {
    public int sub(int x1,int x2) {
        return x1-x2;
    }
}
