package com.huawei.classroom.student.h99.q01;

public class MyT1 {
    public int add(int x1,int x2) {
        return x1+x2;
    }
}
