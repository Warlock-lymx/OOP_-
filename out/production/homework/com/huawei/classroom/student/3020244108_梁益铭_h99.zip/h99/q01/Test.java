package com.huawei.classroom.student.h99.q01;


/*
 * 50分,共计2道题,本题难度系数0星
 */
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//在本包下增加或完善合适的类，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本目录下的程序不要引用其他考题或者作业的类，否则会导致编译失败
		//不能随意读写文件，建立网络连接，访问数据库，创建临时文件目录等

		MyT1 t1=new MyT1();
		//计算两个整数的加和并返回
		if(t1.add(1, 1)==2) {
			System.out.println("pass 1");
		}
	}

}
