package com.huawei.classroom.student.h61;

/**
 * @author super
 */
public class Util {
    public static boolean getOrNotWithProbability(double probability) {
        return Math.random() < probability;
    }
}
