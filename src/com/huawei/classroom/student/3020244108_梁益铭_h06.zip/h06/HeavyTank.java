package com.huawei.classroom.student.h06;

public class HeavyTank extends Tank {
    public HeavyTank(int x, int y) {
        super(x, y, 200, 20, 10);
    }
}
