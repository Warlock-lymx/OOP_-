package com.huawei.classroom.student.h06;

public class Building extends Unit {
    public Building(int x, int y, int hp, int atk, int range) {
        super(x, y, hp, atk, range);
    }
}
