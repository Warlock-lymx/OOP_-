package com.huawei.classroom.student.h06;

public class Tank extends Unit {
    public Tank(int x, int y, int hp, int atk, int range) {
        super(x, y, hp, atk, range);
    }
}
