package com.huawei.classroom.student.h55;

import java.util.Objects;

//创建一个可排序的类
public class sortEntry implements Comparable{
    private String key;
    private Integer count;

    public sortEntry() {
    }

    public sortEntry(String key, int count) {
        this.key = key;
        this.count = count;
    }

    public String getKey(){
        return key;
    }
    public int getCount(){
        return this.count;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        sortEntry se = (sortEntry) obj;
        return Objects.equals(key, se.key) && Objects.equals(count, se.count);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key, count);
    }

    @Override
    public int compareTo(Object obj) {
        sortEntry se = (sortEntry)obj;
        if(this.count > se.count)
            return -1;
        else if(this.count < se.count)
            return 1;
        return 0;
    }
}
